# SeleniumSimplified
a better approach to do automation using selenium python on chrome browser


https://www.freecodecamp.org/news/how-to-create-and-upload-your-first-python-package-to-pypi/